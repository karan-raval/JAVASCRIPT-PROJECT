document.getElementById("login").addEventListener("submit", async (e) => {
    e.preventDefault()

    let usernamename = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let pass = document.getElementById("password").value;

    let d=await fetch("http://localhost:3000/user",)
    let data=await d.json()
    let val=data.filter((el)=>el.email==email)
    if(val.length==0)
        {
            alert("first register")
            window.location.href="signup.html"
        }else{
            if(val[0].password==pass){
                alert("login successfull")
                window.location.href="home.html"
            }else{
                alert("wrong password")
            }
        }
})