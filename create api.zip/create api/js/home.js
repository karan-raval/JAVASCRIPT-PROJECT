document.getElementById("frm").addEventListener("submit", (e) => {
    e.preventDefault()

    let obj = {

        title: document.getElementById("title").value,
        category: document.getElementById("category").value,
        price: document.getElementById("price").value,
        imgurl: document.getElementById("imgurl").value
    }
    fetch("http://localhost:3000/product", {
        method: 'POST',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(obj)
    })
        .then((res) => res.json())
        .then((res) => {
            if (res) {
                alert("iteam add successfully")
            }
        })
})