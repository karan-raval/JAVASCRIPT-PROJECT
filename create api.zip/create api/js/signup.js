document.getElementById("signupfrm").addEventListener("submit", (e) => {
    e.preventDefault()

    let obj = {

        name: document.getElementById("username").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    }
        fetch(`http://localhost:3000/user?email=${obj.email}`)
        .then((res) => res.json())
        .then((res) => {
            if (res.length > 0) {
                alert("user is alredy register")
            }else{
                fetch("http://localhost:3000/user", {
                    method: 'POST',
                    headers: {
                        'content-type': 'application/json'
                    },
                    body: JSON.stringify(obj)
                    })
                    .then((res) => res.json())
                    .then((res) => {
                        if (res) {
                            alert("user successfully registerd")
                            window.location.href = "login.html"
                        }
                })
            }
        })
})